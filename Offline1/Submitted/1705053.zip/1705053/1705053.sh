#!/bin/bash

# Preparing all the directory and the input file variable
working_dir=""
current_dir=$PWD
output_dir="./output_dir"
in_file=""

# No command line argument given
if [[ $# = 0 ]]; then
  #statements
  echo "No directory or input file found : please enter the directory(optional) and name of the file"
  echo "Try inputting : your_script_name.sh path/to/your/directory file_name.txt"
  exit
# One command line argument given
elif [[ $# = 1 ]]; then
  #statements
  if [[ ! -f $1 ]]; then
    #statements
    echo "No file found : please enter a valid file name"
    #echo "Try inputting : your_script_name.sh file_name.txt"
    until [[ "$in_file" != "" ]]; do
      #statements
      echo "Enter the filename again : "
      read name
      if [[ -f "$name" ]]; then
        #statement
        in_file=$name
      fi
    done
  else
    in_file=$1
  fi
# Two command line argument given
elif [[ $# = 2 ]]; then
  #statements
  if [[ ! -d $1 ]]; then
    echo "Invalid input : please check the directory "
    echo "Try inputting : your_script_name.sh path/to/your/directory file_name.txt"
    exit
  elif [[ ! -f $2 ]]; then
    #statements
    echo "No file found : please enter a valid file name"
    until [[ "$in_file" != "" ]]; do
      #statements
      echo "Enter the filename again : "
      read name
      if [[ -f "$name" ]]; then
        #statements
        in_file=$name
      fi
    done
  else
    working_dir=$1
    in_file=$2
  fi
fi

# Getting all the extensions to ignore
arraycounter=0
while read line; do
  #statements4
  #echo "$line"
  line=$(echo "$line" | sed 's/\r$//')
  file_ext[$arraycounter]=$line
  arraycounter+=1
done < $in_file

#echo "${file_ext[@]}"

# Preparing the command to find the required and ignored files
file_comm="find $working_dir -type f"
ignore_comm="find $working_dir -type f"

for each in "${file_ext[@]}"; do
  #statements
  file_comm+=" ! -name *.$each"
  ignore_comm+=" -iname *.$each -o -type f"
done

ignore_comm=${ignore_comm::-32}
#echo "$file_comm"
#echo "$ignore_comm"

run_ignore_comm=$($ignore_comm)
((ignore_count=0))
#echo "${run_ignore_comm[@]}"
IFS=$'\n'
for each in $run_ignore_comm; do
  #
  #echo "$each"
  ((ignore_count++))
done
unset IFS
#echo "$ignore_count"

# Preparing subdirectories and the description text file
all_ext=$($file_comm | sed 's/.*\.//' | sort -u | sed 's/.*\/.*/others/' | sort -u)

declare -A csv_count
for ext in $all_ext; do
  #statements
  mkdir -p "$output_dir/$ext"
  touch "$output_dir/$ext/description_$ext.txt"
  >"output_dir/$ext/description_$ext.txt"
  ((csv_count[$ext]=0))
done

all_files=$($file_comm | sort -u)
#echo "$all_files"

# Getting all the unique files
declare -A unique_files
#echo "$unique_files"
((file_counter=0))
IFS=$'\n'
for file in $all_files; do
  fil_name=$(echo "$file" | sed 's/.*\///')

  if [[ $fil_name = *"."* ]]; then
    fil_ext=$(echo "$fil_name" | sed 's/.*\.//')
  else
    fil_ext="others"
  fi

  #echo "$fil_name"
  boolean="0"
  unset IFS
  for uniq_file in "${unique_files[@]}"; do
    #echo "$uniq_file"
    #echo "$fil_name"
    if [[ "$uniq_file" == "$fil_name" ]]; then
      #statements
      #echo "$fil_name"
      boolean="1"
      break
    fi
  done
  IFS=$'\n'

  if [[ $boolean = "0" ]]; then
    #statements
    #echo "$fil_name"
    unique_files[$file_counter]="$fil_name"
    ((file_counter++))

    cp $file "$output_dir/$fil_ext/$fil_name"
    echo "$file" >>"$output_dir/$fil_ext/description_$fil_ext.txt"
    ((csv_count[$fil_ext]=csv_count[$fil_ext]+1))
  fi
  #echo "${unique_files[@]}"
done
unset IFS
((csv_count["ignored"]=ignore_count))

# Preparing the csv file
touch "output.csv"
>"output.csv"
echo "file_type, no_of_file" >> "output.csv"
for each in ${!csv_count[@]}; do
		echo "$each, ${csv_count[$each]}" >> "output.csv"
done
echo "All the files are organized"
#ssecho "${unique_files[@]}"
