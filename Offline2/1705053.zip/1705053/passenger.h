#include<bits/stdc++.h>

using namespace std;

class Passenger{
    int passenger_id;
    string passenger_name;
    int arrival_time;
    int kiosk_number;
    int belt_number;
    bool has_boarding_pass;
    bool is_vip;
    bool has_boarded;

    public:
        Passenger(){
            passenger_id = -1;
            passenger_name = "";
            arrival_time = 0;
            kiosk_number = 0;
            belt_number = 0;
            has_boarding_pass = false;
            has_boarded = false;
            is_vip = false;
        }

        Passenger(int pass_id) {
            passenger_id = pass_id;
            passenger_name = "Passenger " + to_string(pass_id);
            arrival_time = 0;
            kiosk_number = 0;
            belt_number = 0;
            has_boarding_pass = false;
            has_boarded = false;
            is_vip = false;
        }

        void setID(int id){
            passenger_id = id;
        }

        int getID(){
            return passenger_id;
        }

        void setArrivalTime(int a_time){
            arrival_time = a_time;
        }

        int getArrivaltime(){
            return arrival_time;
        }

        void setName(string name){
            passenger_name = name;
        }

        string getName(){
            return passenger_name;
        }

        void addName(string parts){
            passenger_name = passenger_name + parts;
        }

        void setKioskNumber(int num){
            kiosk_number = num;
        }

        int getKioskNumber(){
            return kiosk_number;
        }

        void setBeltNumber(int num){
            belt_number = num;
        }

        int getBeltNumber(){
            return belt_number;
        }

        void setBoardingPass(bool flag){
            has_boarding_pass = flag;
        }

        bool hasBoardingPass(){
            return has_boarding_pass;
        }

        void setBoarded(bool flag){
            has_boarded = flag;
        }

        bool hasBoarded(){
            return has_boarded;
        }

        void setVIP(bool flag){
            is_vip = flag;
        }

        bool isVIP(){
            return is_vip;
        }
};